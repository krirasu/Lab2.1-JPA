package com.cg.dto;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="author_master")
public class Author implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	private String aId;
	private String aName;
	
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="authors")
	private Set<Book> books = new HashSet<>();
	
	public String getaId() 
	{
		return aId;
	}
	public void setaId(String aId) 
	{
		this.aId = aId;
	}
	public String getaName() 
	{
		return aName;
	}
	public void setaName(String aName) 
	{
		this.aName = aName;
	}
	
	public Set<Book> getBooks() {
		return books;
	}

	public void setBooks(Set<Book> books) {
		this.books = books;
	}	
}
