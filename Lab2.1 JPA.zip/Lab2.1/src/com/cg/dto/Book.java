package com.cg.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "book_master")
		
public class Book implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	@Id
	private String bIsbn;
	
	@Column(name = "book_title")
	private String bTitle;
	private float bPrice;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "author_books", joinColumns = { @JoinColumn(name = "book_isbn") }, inverseJoinColumns = { @JoinColumn(name = "author_id") })
	private Set<Author> authors = new HashSet<>();
		
	public String getbIsbn()
	{
		return bIsbn;
	}
	public void setbIsbn(String bIsbn)
	{
		this.bIsbn = bIsbn;
	}
	public String getbTitle() 
	{
		return bTitle;
	}
	public void setbTitle(String bTitle) 
	{
		this.bTitle = bTitle;
	}
	public float getbPrice() 
	{
		return bPrice;
	}
	public void setbPrice(float bPrice) 
	{
		this.bPrice = bPrice;
	}
	
	public Set<Author> getAuthors() {
		return authors;
	}

	public void setAuthors(Set<Author> authors) {
		this.authors = authors;
	}
	
	public void addAuthor(Author author) {
		this.getAuthors().add(author);
	}
}
