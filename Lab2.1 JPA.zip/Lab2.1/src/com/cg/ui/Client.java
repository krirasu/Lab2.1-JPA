package com.cg.ui;
import java.util.Date;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.dto.Author;
import com.cg.dto.Book;

public class Client 
{
	public static void main(String[] args)
	{
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		
		Author aAuthor = new Author();
		aAuthor.setaId("1");
		aAuthor.setaName("Sherlock Holmes");

		Author bAuthor = new Author();
		bAuthor.setaId("2");
		bAuthor.setaName("Enid Blyton");
	
		Author cAuthor = new Author();
		cAuthor.setaId("3");
		cAuthor.setaName("Amish");

		// now define first book and add few authors in it
		Book firstBook = new Book();
		firstBook.setbIsbn("1000");
		firstBook.setbTitle("A");
		firstBook.setbPrice(900.00F);

		firstBook.addAuthor(aAuthor);
		firstBook.addAuthor(bAuthor);
		firstBook.addAuthor(cAuthor);
		
		// now define second order and add few products in it
		Book secondBook = new Book();
		secondBook.setbIsbn("1001");
		secondBook.setbTitle("B");
		secondBook.setbPrice(800.00F);

		secondBook.addAuthor(aAuthor);		
		secondBook.addAuthor(bAuthor);
		secondBook.addAuthor(cAuthor);
		
		// save orders using entity manager
		em.persist(firstBook);
		em.persist(secondBook);
		
		System.out.println("Added Books along with book details to database.");
		
		em.getTransaction().commit();
		em.close();
		factory.close();
	}
}
